### Skrivkramp
Ladda ner Skrivkramp.jar, k�r programmet - d� skapas phrases.dat i samma map.
Fyll den sedan med fraser som finns i phrases.dat h�r i repositryn. 
K�r sedan igen s� funkar allt.